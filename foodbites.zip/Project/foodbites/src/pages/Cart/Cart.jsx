import React, { useContext } from 'react';
import './Cart.css';
import { StoreContext } from '../../context/StoreContext';
import Footer from '../../components/Footer/Footer';
import { useNavigate } from 'react-router-dom';
import { useOrdersList } from '../../hooks/useOrdersList';
import useAuthState from '../../hooks/use-auth-state';
import { addDoc, collection } from 'firebase/firestore';
import { db } from "../../config/firebase-config.js";

 // Make sure the Firebase db import is correct

const Cart = () => {
  const { cartItems, food_list, removeFromCart, getTotalCartAmount } = useContext(StoreContext);
  const { user, loading } = useAuthState();
  const orderList = useOrdersList(user?.uid || '');
  const navigate = useNavigate();

  if (loading) {
    return <div>Loading...</div>;
  }

  // Function to add the cart data to Firestore
  const addOrderToFirestore = async () => {
    if (!user?.uid) {
      console.error("User is not authenticated");
      return;
    }

    const orderData = {
      items: food_list.map(item => ({
        id: item._id,
        name: item.name,
        price: item.price,
        quantity: cartItems[item._id] || 0,
      })).filter(item => item.quantity > 0), // Only include items that are in the cart
      totalAmount: getTotalCartAmount() + 2, // Assuming a $2 delivery fee
      createdAt: new Date(),
    };

    try {
      const colRef = collection(db, "users", user.uid, "orders");
      await addDoc(colRef, orderData);
      console.log("Order added to Firestore successfully");
      // Redirect user to the order confirmation or another page
      navigate('/order');
    } catch (e) {
      console.error("Error adding order to Firestore: ", e);
    }
  };

  return (
    <div className="cart">
      <div className="cart-items">
        <div className="cart-items-title">
          <p>Image</p>
          <p>Title</p>
          <p>Price</p>
          <p>Quantity</p>
          <p>Total</p>
          <p>Remove</p>
        </div>
        <br />
        <hr />
        {food_list.map((item) => {
          const count = cartItems[item._id];
          if (count > 0) {
            return (
              <React.Fragment key={item._id}>
                <div className="cart-items-title cart-items-item">
                  <img src={item.image} alt={item.name} />
                  <p>{item.name}</p>
                  <p>${item.price}</p>
                  <p>{count}</p>
                  <p>${item.price * count}</p>
                  <p className="cross" onClick={() => removeFromCart(item._id)}>x</p>
                </div>
                <br />
                <hr />
              </React.Fragment>
            );
          }
          return null;
        })}
      </div>

      <div className="cart-bottom">
        <div className="cart-total">
          <h2>Cart Totals</h2>
          <div>
            <div className="cart-total-details">
              <p>Subtotal</p>
              <p>${getTotalCartAmount()}</p>
            </div>
            <div className="cart-total-details">
              <p>Delivery fee</p>
              <p>${getTotalCartAmount() === 0 ? 0 : 2}</p>
            </div>
            <div className="cart-total-details">
              <b>Total</b>
              <b>${getTotalCartAmount() === 0 ? 0 : getTotalCartAmount() + 2}</b>
            </div>
          </div>
          <button onClick={addOrderToFirestore}>Proceed to Checkout</button>
        </div>

        <div className="cart-promocode">
          <div>
            <p>If you have a promo code, enter it here</p>
            <div className="cart-promocode-input">
              <input type="text" placeholder="Promo code" />
              <button>Submit</button>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Cart;
