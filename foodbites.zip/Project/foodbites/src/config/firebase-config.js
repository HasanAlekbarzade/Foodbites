// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { addDoc, collection, getFirestore, setDoc, doc } from "firebase/firestore";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDw_XPDHXaKTma-5S84G29mNB1Lufg6yxM",
  authDomain: "goguli-60c53.firebaseapp.com",
  projectId: "goguli-60c53",
  storageBucket: "goguli-60c53.firebasestorage.app",
  messagingSenderId: "836888411654",
  appId: "1:836888411654:web:48bf73c743b5b8ee8a4d87"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

// Function to get the orders collection for a user
export const colRef = (uid) => collection(db, "users", uid, "orders");

// Sample order data to be added
const orderData = {
  items: [
    { id: "item1", name: "Pizza", quantity: 2, price: 10 },
    { id: "item2", name: "Burger", quantity: 1, price: 5 }
  ],
  totalAmount: 25,
  createdAt: new Date()
};

// Function to add an order to Firestore
export const addOrder = async (uid, orderData) => {
  try {
    // You can choose to either generate a new document or use a custom ID
    const docRef = await addDoc(colRef(uid), orderData);  // Creates a new document with an auto-generated ID
    console.log("Order added with ID:", docRef.id);
  } catch (error) {
    console.error("Error adding order: ", error);
  }
};

// Call the function to add an order for a user
addOrder("1", orderData);
