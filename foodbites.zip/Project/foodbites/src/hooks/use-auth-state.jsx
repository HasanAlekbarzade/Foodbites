import { useEffect, useState } from "react";
import { auth } from "../config/firebase-config";

export default function useAuthState() {
    
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        auth.onAuthStateChanged((user) => {
            if (user) {
                setUser(user);
            } else {
                setUser(null);
            }
            setLoading(false);
        });
    }, []);

    return { user, loading };
}
