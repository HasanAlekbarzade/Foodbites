import React from 'react';
import { assets } from '../../assets/assets';
import './Footer.css';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <div className='footer'>
        <div className="footer" id="footer">
            <div className="footer-content">
                <div className="footer-content-left">
         <Link to='/' id ='logo'><img className='logo-img' src={assets.logo} alt="" /></Link>
         <p>At Foodbite, we believe every meal is an experience to savor. Our restaurant blends culinary creativity with the finest ingredients to bring you dishes that delight every palate.
             Whether you're craving a hearty breakfast, a savory dinner, or a decadent dessert, our chefs are here to serve flavors that feel like home with a gourmet twist. With a cozy ambiance, exceptional service, and a menu crafted with love, Foodbite is your go-to destination for unforgettable dining moments.</p>
             <div className="footer-social-icon">
                <img src={assets.facebook_icon} alt="" />
                <img  src={assets.twitter_icon} alt="" />
                <a href="https://www.linkedin.com/in/hasan-alakbarzade/"><img src={assets.linkedin_icon} alt="" /></a> 
                </div>  
               
                </div>
                <div className="footer-content-right">
               <h2>COMPANY</h2>
               <ul>
                <li>Home</li>
                <li>About Us</li>
                <li>Delivery</li>
                <li>Privacy policy</li>
               </ul>
                </div>
                <div className="footer-content-center">
<h2>GET IN TOUCH</h2>
<ul>
    <li>+994-664-40-28</li>
    <li>hesenelekberzade32@gmail.com</li>
</ul>
                </div>
            </div>
            <hr />
            <p className="footer-copyright">Copyright 2025 © Right Reserved by Hasan Alakbarzada🔥</p>
        </div>
    </div>
  )
}

export default Footer