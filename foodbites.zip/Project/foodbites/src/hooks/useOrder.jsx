import { useEffect, useState } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '@/firebase';

export const useOrder = (uid, orderId) => {
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!uid || !orderId) return;
    const ref = doc(db, 'users', uid, 'orders', orderId);
    const unsub = onSnapshot(ref, (snapshot) => {
      setOrder({ id: snapshot.id, ...snapshot.data() });
      setLoading(false);
    });

    return () => unsub();
  }, [uid, orderId]);

  return { order, loading };
};
