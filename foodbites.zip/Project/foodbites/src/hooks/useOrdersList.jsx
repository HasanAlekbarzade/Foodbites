import { useEffect, useState } from 'react';
import { collection, onSnapshot, query } from 'firebase/firestore';
import { db } from '../config/firebase-config.js'// Adjust this to your firebase config

export const useOrdersList = (uid) => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!uid) return;
    const q = query(collection(db, 'users', uid, 'orders'));
    const unsub = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }))  ;
      setOrders(data);
      setLoading(false);
    });

    return () => unsub();
  }, [uid]);

  return { orders, loading };
};
